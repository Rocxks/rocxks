#pragma once

#define HTTP_SERVER "45.128.232.23"
#define HTTP_PORT 80

#define TFTP_SERVER "45.128.232.23"
